function GetDate(date)
{
    var month=["January","February","March","April","May","June","July", "August","September","October","November","December"];
    var f=date.split("-")
    var da=month[parseInt(f[1])-1]+" "+f[2]+", "+f[0]
    return da;
}